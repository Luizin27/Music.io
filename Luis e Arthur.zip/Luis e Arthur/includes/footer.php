<div class="container">
  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="foot" title="Rock"><a href="Albuns.php" class="nav-link px-2 text-muted">Contatos</a></li>
      <li class="foot" title="homee"><a href="index.php" class="nav-link px-2 text-muted">Home</a></li>
      <li class="foot" title="rap"><a href="Instrumentos.php" class="nav-link px-2 text-muted">Sobre</a></li>
    </ul>
    <p class="text-center text-muted">© 2022 Ensino Médio Senac</p>
    <p class="text-center text-muted">Luis e Arthur</p>
  </footer>
</div>


</div>

<!-- Option 1: Bootstrap Bundle with Popper -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

<body>
   </html>